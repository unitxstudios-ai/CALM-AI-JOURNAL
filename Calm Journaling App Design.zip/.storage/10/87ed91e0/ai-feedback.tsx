import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";

interface AIFeedbackProps {
  journalEntries: Array<{
    id: string;
    title: string;
    content: string;
    mood: string;
    createdAt: Date;
  }>;
}

export function AIFeedback({ journalEntries }: AIFeedbackProps) {
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Mock AI feedback generation
  const generateFeedback = () => {
    setLoading(true);
    
    // Simulate API delay
    setTimeout(() => {
      // Simple mock AI feedback based on entries
      let mockFeedback = "";
      
      if (journalEntries.length === 0) {
        mockFeedback = "Start journaling to receive AI insights about your mood patterns and reflections.";
      } else if (journalEntries.length < 3) {
        mockFeedback = "I notice you're starting to build a journaling habit. Keep it up! More entries will help me provide deeper insights about your patterns and moods.";
      } else {
        const moods = journalEntries.map(entry => entry.mood.toLowerCase());
        const moodCounts: Record<string, number> = {};
        
        moods.forEach(mood => {
          moodCounts[mood] = (moodCounts[mood] || 0) + 1;
        });
        
        const dominantMood = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0][0];
        
        const recentEntries = journalEntries.slice(0, 3);
        const recentMoods = recentEntries.map(entry => entry.mood.toLowerCase());
        
        if (recentMoods.every(mood => mood === recentMoods[0])) {
          mockFeedback = `I've noticed that your recent entries reflect a consistent ${recentMoods[0]} mood. This consistency can be insightful about your current life phase.`;
        } else {
          mockFeedback = `Your journal shows a variety of emotions recently, with ${dominantMood} being most frequent overall. Emotional variety is a sign of a rich inner life and self-awareness.`;
        }
        
        // Add a random insight
        const insights = [
          "Consider setting aside specific times for journaling to build a consistent habit.",
          "Reflecting on past entries can help you see patterns in your emotional responses.",
          "Writing about gratitude has been shown to increase overall well-being over time.",
          "When feeling overwhelmed, try journaling with a timer set for just 5 minutes to focus your thoughts."
        ];
        
        mockFeedback += " " + insights[Math.floor(Math.random() * insights.length)];
      }
      
      setFeedback(mockFeedback);
      setLoading(false);
    }, 1500);
  };

  return (
    <Card className={cn(
      "transition-all duration-300 overflow-hidden",
      "border-none shadow-md dark:bg-slate-900/60 bg-white/60 backdrop-blur-sm"
    )}>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-lg font-medium">
          <Sparkles className="h-5 w-5 text-amber-500" />
          AI Reflection
        </CardTitle>
        <CardDescription>
          Get insights based on your journal entries
        </CardDescription>
      </CardHeader>
      <CardContent>
        {feedback ? (
          <p className="text-sm text-muted-foreground">{feedback}</p>
        ) : (
          <p className="text-sm text-muted-foreground">
            Click the button below to generate personalized reflections about your journaling patterns.
          </p>
        )}
      </CardContent>
      <CardFooter>
        <Button 
          onClick={generateFeedback} 
          disabled={loading || journalEntries.length === 0}
          variant="outline" 
          className="w-full flex items-center gap-2"
        >
          {loading ? (
            <>
              <RefreshCw className="h-4 w-4 animate-spin" />
              Reflecting...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4" />
              Generate Insight
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}