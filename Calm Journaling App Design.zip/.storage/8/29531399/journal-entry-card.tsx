import { formatDistanceToNow } from "date-fns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

interface JournalEntryCardProps {
  entry: {
    id: string;
    title: string;
    content: string;
    mood: string;
    createdAt: Date;
  };
  onDelete: (id: string) => void;
}

export function JournalEntryCard({ entry, onDelete }: JournalEntryCardProps) {
  const [expanded, setExpanded] = useState(false);

  const formattedTime = formatDistanceToNow(new Date(entry.createdAt), { 
    addSuffix: true 
  });

  // Map mood to appropriate color
  const moodColors: Record<string, string> = {
    happy: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    calm: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    sad: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200",
    anxious: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
    grateful: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    frustrated: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  };

  const moodColor = moodColors[entry.mood.toLowerCase()] || "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";

  return (
    <Card className="mb-4 transition-all duration-300 hover:shadow-md overflow-hidden">
      <CardHeader className="pb-2 relative">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl font-medium">{entry.title}</CardTitle>
            <CardDescription className="text-sm mt-1">{formattedTime}</CardDescription>
          </div>
          <div className="flex gap-2 items-center">
            <span className={cn("px-2 py-1 rounded-full text-xs font-medium", moodColor)}>
              {entry.mood}
            </span>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => onDelete(entry.id)}
              className="text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
              <span className="sr-only">Delete entry</span>
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className={cn(
          "text-muted-foreground transition-all duration-300",
          expanded ? "" : "line-clamp-3"
        )}>
          {entry.content}
        </div>
        {entry.content.length > 150 && (
          <Button 
            variant="ghost" 
            onClick={() => setExpanded(!expanded)} 
            className="text-xs mt-2 h-auto py-1"
          >
            {expanded ? "Show less" : "Read more"}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}