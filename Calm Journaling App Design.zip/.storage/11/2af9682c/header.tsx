import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { PenLine, BookText } from "lucide-react";

interface HeaderProps {
  onNewEntry: () => void;
}

export function Header({ onNewEntry }: HeaderProps) {
  return (
    <header className="sticky top-0 z-10 backdrop-blur-lg bg-white/50 dark:bg-slate-950/50 border-b">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BookText className="h-6 w-6 text-indigo-500" />
          <h1 className="text-xl font-serif font-medium">Mind Dump</h1>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            onClick={onNewEntry}
            className="bg-gradient-to-r from-blue-400 to-indigo-400 hover:from-blue-500 hover:to-indigo-500 text-white"
          >
            <PenLine className="h-4 w-4 mr-2" /> 
            New Entry
          </Button>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}