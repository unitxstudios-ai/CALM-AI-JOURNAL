import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X } from "lucide-react";

const formSchema = z.object({
  title: z.string().min(1, "Title is required").max(100),
  content: z.string().min(1, "Journal entry content is required"),
  mood: z.string().min(1, "Please select a mood"),
});

type EntryFormData = z.infer<typeof formSchema>;

interface JournalEntryFormProps {
  onSubmit: (data: EntryFormData) => void;
  onCancel: () => void;
}

export function JournalEntryForm({ onSubmit, onCancel }: JournalEntryFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<EntryFormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      content: "",
      mood: "",
    },
  });

  const handleSubmit = async (data: EntryFormData) => {
    setIsSubmitting(true);
    try {
      onSubmit(data);
      form.reset();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto mb-8 border-none shadow-lg dark:bg-slate-900/80 bg-white/90 backdrop-blur-sm">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl font-serif">New Journal Entry</CardTitle>
                <CardDescription className="mt-1.5">
                  What's on your mind today?
                </CardDescription>
              </div>
              <Button 
                type="button" 
                variant="ghost" 
                size="icon" 
                onClick={onCancel}
                className="text-muted-foreground"
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Close</span>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Give your entry a title..." 
                      {...field} 
                      className="focus-visible:ring-offset-0"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="mood"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>How are you feeling?</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="focus-visible:ring-offset-0">
                        <SelectValue placeholder="Select a mood" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Happy">Happy</SelectItem>
                      <SelectItem value="Calm">Calm</SelectItem>
                      <SelectItem value="Sad">Sad</SelectItem>
                      <SelectItem value="Anxious">Anxious</SelectItem>
                      <SelectItem value="Grateful">Grateful</SelectItem>
                      <SelectItem value="Frustrated">Frustrated</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Journal Entry</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Write freely about your thoughts and feelings..."
                      className="min-h-[200px] resize-none focus-visible:ring-offset-0"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter>
            <Button 
              type="submit" 
              disabled={isSubmitting} 
              className="w-full bg-gradient-to-r from-blue-400 to-indigo-400 hover:from-blue-500 hover:to-indigo-500 text-white"
            >
              {isSubmitting ? "Saving..." : "Save Entry"}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}