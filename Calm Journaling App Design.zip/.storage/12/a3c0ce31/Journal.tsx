import { useState, useEffect } from "react";
import { v4 as uuidv4 } from "uuid";
import { Header } from "@/components/journal/header";
import { JournalEntryForm } from "@/components/journal/journal-entry-form";
import { JournalEntryCard } from "@/components/journal/journal-entry-card";
import { AIFeedback } from "@/components/journal/ai-feedback";

interface JournalEntry {
  id: string;
  title: string;
  content: string;
  mood: string;
  createdAt: Date;
}

export default function JournalPage() {
  const [showEntryForm, setShowEntryForm] = useState(false);
  const [entries, setEntries] = useState<JournalEntry[]>([]);

  // Load entries from localStorage on mount
  useEffect(() => {
    const savedEntries = localStorage.getItem("journalEntries");
    if (savedEntries) {
      try {
        setEntries(JSON.parse(savedEntries));
      } catch (error) {
        console.error("Failed to parse journal entries:", error);
      }
    }
  }, []);

  // Save entries to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("journalEntries", JSON.stringify(entries));
  }, [entries]);

  const handleNewEntry = () => {
    setShowEntryForm(true);
  };

  const handleCancelEntry = () => {
    setShowEntryForm(false);
  };

  const handleSubmitEntry = (data: { title: string; content: string; mood: string }) => {
    const newEntry: JournalEntry = {
      id: uuidv4(),
      title: data.title,
      content: data.content,
      mood: data.mood,
      createdAt: new Date(),
    };

    setEntries([newEntry, ...entries]);
    setShowEntryForm(false);
  };

  const handleDeleteEntry = (id: string) => {
    setEntries(entries.filter(entry => entry.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-950 dark:to-indigo-950 transition-colors duration-300">
      <Header onNewEntry={handleNewEntry} />
      
      <main className="container mx-auto px-4 py-6">
        {showEntryForm && (
          <JournalEntryForm onSubmit={handleSubmitEntry} onCancel={handleCancelEntry} />
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="col-span-1 lg:col-span-2 space-y-4">
            <h2 className="text-lg font-medium text-muted-foreground mb-4 font-serif">
              {entries.length > 0 
                ? "Your Journal Timeline" 
                : "Your journal is empty. Start writing your first entry!"}
            </h2>
            
            <div className="space-y-4">
              {entries.map(entry => (
                <JournalEntryCard 
                  key={entry.id} 
                  entry={entry} 
                  onDelete={handleDeleteEntry} 
                />
              ))}
            </div>
          </div>
          
          <div className="col-span-1">
            <div className="sticky top-24">
              <AIFeedback journalEntries={entries} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}